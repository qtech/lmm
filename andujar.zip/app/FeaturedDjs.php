<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FeaturedDjs extends Model
{
    protected $table = "featured_djs";
    public $primaryKey = "feature_dj_id";
}
