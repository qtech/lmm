<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppLinks extends Model
{
    protected $table = "shares";
    public $primaryKey = "share_id";
}
