<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Images extends Model
{
    protected $table = "images_folder";
    public $primaryKey = "folder_id";
}
