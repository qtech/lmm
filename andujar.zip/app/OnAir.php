<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OnAir extends Model
{
    protected $table = "onair";
    public $primaryKey = "onair_id";
}
