<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Albums;
use Validator;
use Storage;
class AlbumsController extends Controller
{
    public function index()
    {
    	$albums = Albums::orderBy('album_id','desc')->paginate(10);
    	return view('albums.main')->with('albums',$albums);
    }

    public function add()
    {
    	return view('albums.create');
    }

    public function store(Request $request)
    {
    	$validator = Validator::make($request->all(),[
    			'album_name' => 'required|string|max:50',
    			'album_image' => 'required|image',
                'insta_url' => 'required|url|max:255'
    		]);

    	if($validator->fails())
    	{
    		return redirect()->route('albums.add')->withErrors($validator)->withInput(['album_name'=>$request->album_name]);
    	}
    	else
    	{
    		if($request->hasFile('album_image'))
    		{
    			//Get filename with extension
        		$fileNameWithExt = $request->file('album_image')->getClientOriginalName();
        		$fileNameWithExt = str_replace(" ", "_", $fileNameWithExt);        		
        		//Get only file name
        		$filename = pathinfo($fileNameWithExt, PATHINFO_FILENAME);
                $filename = preg_replace("/[^a-zA-Z0-9\s]/", "", $filename);
                $filename = urlencode($filename);
        		//Get extension
        		$extension = $request->file('album_image')->getClientOriginalExtension();
        		//FileName to Store
        		$fileNameToStore = $filename.'_'.time().'.'.$extension;
        		//Upload the image
        		$path = $request->file('album_image')->storeAs('public/uploads',$fileNameToStore);
    		}
    		else
    		{
    			$fileNameToStore = "default_album_image.png";
    		}

    		$album = new Albums;
    		$album->album_name = $request->album_name;
            $album->insta_url = $request->insta_url;
    		$album->image = $fileNameToStore;
    		$album->save();

    		return redirect()->route('albums.add')->with('success','Album Successfully Added.');
    	}
    }

    public function edit($id)
    {
    	$album = Albums::find($id);
    	return view('albums.edit')->with('album',$album);
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(),[
                'album_name' => 'required|string|max:50',
                'album_image' => 'image|nullable',
                'insta_url' => 'required|url|max:255'
            ]);

        if($validator->fails())
        {
            return redirect()->route('albums.edit',['id'=>$id])->withErrors($validator)->withInput(['album_name'=>$request->album_name]);
        }
        else
        {
            if($request->hasFile('album_image'))
            {
                //Get filename with extension
                $fileNameWithExt = $request->file('album_image')->getClientOriginalName();
                $fileNameWithExt = str_replace(" ", "_", $fileNameWithExt);             
                //Get only file name
                $filename = pathinfo($fileNameWithExt, PATHINFO_FILENAME);
                $filename = preg_replace("/[^a-zA-Z0-9\s]/", "", $filename);
                $filename = urlencode($filename);
                //Get extension
                $extension = $request->file('album_image')->getClientOriginalExtension();
                //FileName to Store
                $fileNameToStore = $filename.'_'.time().'.'.$extension;
                //Upload the image
                $path = $request->file('album_image')->storeAs('public/uploads',$fileNameToStore);
            }            

            $album = Albums::find($id);
            $album->album_name = $request->album_name;
            $album->insta_url = $request->insta_url;
            if($request->hasFile('album_image'))
            {
                Storage::delete('public/uploads/'.$album->image);
                $album->image = $fileNameToStore;
            }
            $album->save();

            return redirect()->route('albums.edit',['id'=>$id])->with('success','Album Information Successfully Updated.');
        }
    }

    public function destroy($id)
    {
        $album = Albums::find($id);
        if($album->image != NULL)
        {
            Storage::delete('public/uploads/'.$album->image);            
        }

        $album->delete();

        return redirect()->route('albums.index')->with('success','Album Successfully Removed.');
    }
}
