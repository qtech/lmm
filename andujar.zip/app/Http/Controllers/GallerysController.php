<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Gallery;
use App\Images;
use Validator;
use Storage;
class GallerysController extends Controller
{
    public function index()
    {
    	$galleries = Gallery::with('folder')->orderBy('gallery_id', 'desc')->paginate(10);
    	return view('gallery.main')->with('galleries', $galleries);
    }

    public function add()
    {
    	$folders = Images::all();
    	return view('gallery.create')->with('folders', $folders);
    }

    public function store(Request $request)
    {
    	if($request->folder_id == "null")
    	{
    		return redirect()->route('gallerys.add')->with('error','Please select a folder to add this image.');
    	}
    	else
    	{
    		$validator = Validator::make($request->all(),[
    				'gallery_image' => 'required|image'
    			]);

    		if($validator->fails())
    		{
    			return redirect()->route('gallerys.add')->withErrors($validator);
    		}
    		else
    		{
    			//Get filename with extension
        		$fileNameWithExt = $request->file('gallery_image')->getClientOriginalName();
        		$fileNameWithExt = str_replace(" ", "_", $fileNameWithExt);        		
        		//Get only file name
        		$filename = pathinfo($fileNameWithExt, PATHINFO_FILENAME);
                $filename = preg_replace("/[^a-zA-Z0-9\s]/", "", $filename);
                $filename = urlencode($filename);
        		//Get extension
        		$extension = $request->file('gallery_image')->getClientOriginalExtension();
        		//FileName to Store
        		$fileNameToStore = $filename.'_'.time().'.'.$extension;
        		//Upload the image
        		$path = $request->file('gallery_image')->storeAs('public/uploads',$fileNameToStore);

        		$gallery = new Gallery;
        		$gallery->folder_id = $request->folder_id;
        		$gallery->image = $fileNameToStore;
        		$gallery->save();

        		return redirect()->route('gallerys.add')->with('success','Image successfully added to folder.');
    		}
    	}
    }

    public function edit($id)
    {
    	$data = array(
    			'gallery' => Gallery::with('folder')->find($id),
    			'folders' => Images::all(),
    		);    
    	
    	return view('gallery.edit')->with($data);
    }

    public function update(Request $request, $id)
    {
    	if($request->folder_id == "null")
    	{
    		return redirect()->route('gallerys.edit',['id'=>$id])->with('error','Please select a folder to add this image.');
    	}
    	else
    	{
    		$validator = Validator::make($request->all(),[
    				'gallery_image' => 'nullable|image'
    			]);

    		if($validator->fails())
    		{
    			return redirect()->route('gallerys.edit',['id'=>$id])->withErrors($validator);
    		}
    		else
    		{
    			if($request->hasFile('gallery_image'))
    			{
    				//Get filename with extension
	        		$fileNameWithExt = $request->file('gallery_image')->getClientOriginalName();
	        		$fileNameWithExt = str_replace(" ", "_", $fileNameWithExt);        		
	        		//Get only file name
	        		$filename = pathinfo($fileNameWithExt, PATHINFO_FILENAME);
                    $filename = preg_replace("/[^a-zA-Z0-9\s]/", "", $filename);
                    $filename = urlencode($filename);
	        		//Get extension
	        		$extension = $request->file('gallery_image')->getClientOriginalExtension();
	        		//FileName to Store
	        		$fileNameToStore = $filename.'_'.time().'.'.$extension;
	        		//Upload the image
	        		$path = $request->file('gallery_image')->storeAs('public/uploads',$fileNameToStore);
    			}
    			
        		$gallery = Gallery::find($id);
        		$gallery->folder_id = $request->folder_id;
        		if($request->hasFile('gallery_image'))
        		{
        			Storage::delete('public/uploads/'.$gallery->image);
        			$gallery->image = $fileNameToStore;	

        		}        		
        		$gallery->save();

        		return redirect()->route('gallerys.edit',['id'=>$id])->with('success','Image information successfully updated.');
    		}
    	}
    }

    public function destroy($id)
    {
    	$gallery = Gallery::find($id);
    	Storage::delete('public/uploads/'.$gallery->image);
    	$gallery->delete();

    	return redirect()->route('gallerys.index')->with('success','Image removed from this folder.');
    }


}
