<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class video_day extends Model
{
    //
    protected $table="video_of_the_day";
}
